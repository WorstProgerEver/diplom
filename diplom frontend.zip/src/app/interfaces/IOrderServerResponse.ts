export interface IOrderServerResponse {
  id: number;
  title: string;
  description: string;
  price: number;
  quantityOrder: number;
  image: string;
}
