export interface IProduct{
  id: number;
  name: string;
  category: string;
  description: string;
  price: number;
  image: string;
  images: string;
  quantity: number;
}
